/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package de.hybris.platform.marketplaceintegrationbackoffice.renderer;


import de.hybris.platform.marketplaceintegrationbackoffice.utils.MarketplaceintegrationbackofficeRestTemplateUtil;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.util.Config;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.zkoss.json.JSONObject;
import org.zkoss.util.resource.Labels;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zul.Button;

import com.hybris.backoffice.model.MarketplaceModel;
import com.hybris.backoffice.model.MarketplaceSellerModel;
import com.hybris.backoffice.model.MarketplaceStoreModel;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationEvent;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationUtils;
import com.hybris.cockpitng.core.config.impl.jaxb.editorarea.AbstractPanel;
import com.hybris.cockpitng.core.util.CockpitProperties;
import com.hybris.cockpitng.dataaccess.facades.object.ObjectFacade;
import com.hybris.cockpitng.dataaccess.facades.permissions.PermissionFacadeStrategy;
import com.hybris.cockpitng.dataaccess.facades.type.DataType;
import com.hybris.cockpitng.engine.WidgetInstanceManager;
import com.hybris.cockpitng.widgets.editorarea.renderer.impl.AbstractEditorAreaPanelRenderer;


public class MarketplaceIntegrationOrderIncrementalRenderer extends AbstractEditorAreaPanelRenderer<MarketplaceStoreModel>
{
	private static final Logger LOG = LoggerFactory.getLogger(MarketplaceIntegrationOrderIncrementalRenderer.class);

	public static final String MARKETPLACE_ORDER_REALTIME_SYNC_PATH = "marketplace.order.realtime.sync.path";
	public static final String MARKETPLACE_ORDER_SYCHRONIZE_MIDDLE_PATH = "marketplace.order.sychronize.middle.path";

	private ModelService modelService;
	private CockpitProperties cockpitProperties;
	private PermissionFacadeStrategy permissionFacadeStrategy;
	private ObjectFacade objectFacade;
	private WidgetInstanceManager widgetInstanceManager;
	@Autowired
	private MarketplaceintegrationbackofficeRestTemplateUtil marketplaceHttpUtil;

	@Override
	public void render(final Component parent, final AbstractPanel panel, final MarketplaceStoreModel data, final DataType type,
			final WidgetInstanceManager widgetInstanceManager)
	{
		this.widgetInstanceManager = widgetInstanceManager;
		final Button loadBtnEnable = new Button(Labels.getLabel("backoffice.button.marketplacestore.subscribeorder.enable"));
		final Button loadBtnDisable = new Button(Labels.getLabel("backoffice.button.marketplacestore.subscribeorder.disable"));

		loadBtnEnable.setSclass("initial-load-box");
		loadBtnEnable.addEventListener(Events.ON_CLICK,
				event -> {
					if (incrementalOrderDownload(data, "ON"))
					{
						data.setSubscribeorder(Boolean.TRUE);
						this.modelService.save(data);
						parent.removeChild(loadBtnEnable);
						parent.appendChild(loadBtnDisable);
					}
					else
					{
						NotificationUtils.notifyUserVia(Labels.getLabel("subscribe.order.enable.status"),
								NotificationEvent.Type.WARNING, "");
						LOG.warn("enable order subscription failed. reason: connection error!");
						return;
					}
				});
		loadBtnDisable.setSclass("initial-load-box");
		loadBtnDisable.addEventListener(Events.ON_CLICK,
				event -> {
					if (incrementalOrderDownload(data, "OFF"))
					{
						data.setSubscribeorder(Boolean.FALSE);
						this.modelService.save(data);
						parent.removeChild(loadBtnDisable);
						parent.appendChild(loadBtnEnable);
					}
					else
					{
						NotificationUtils.notifyUserVia(Labels.getLabel("subscribe.order.disable.status"),
								NotificationEvent.Type.WARNING, "");
						LOG.warn("disable order subscription failed. reason: connection error!");
						return;
					}
				});
		if (data.getSubscribeorder() == Boolean.FALSE)
		{
			parent.appendChild(loadBtnEnable);
		}
		else if (data.getSubscribeorder() == Boolean.TRUE)
		{
			parent.appendChild(loadBtnDisable);
		}

	}

	private boolean incrementalOrderDownload(final MarketplaceStoreModel model, final String status)
	{
		final MarketplaceSellerModel seller = model.getMarketplaceSeller();
		final MarketplaceModel marketPlace = seller.getMarketplace();
		boolean flag = false;
		modelService.refresh(seller);

		final String requestUrl = marketPlace.getAdapterUrl() + Config.getParameter(MARKETPLACE_ORDER_REALTIME_SYNC_PATH)
				+ Config.getParameter(MARKETPLACE_ORDER_SYCHRONIZE_MIDDLE_PATH) + model.getIntegrationId();
		final JSONObject jsonObj = new JSONObject();
		jsonObj.put("currency", model.getCurrency().getIsocode());
		jsonObj.put("productCatalogVersion", model.getCatalogVersion().getCatalog().getId() + ":"
				+ model.getCatalogVersion().getVersion());
		jsonObj.put("status", status);

		try
		{
			final Map<String, Object> results = marketplaceHttpUtil.post(requestUrl, jsonObj.toJSONString());
			final int httpStatus = Integer.parseInt(results.get("code").toString());
			flag = httpStatus == 200;
		}
		catch (final Exception e)
		{
			LOG.error(e.toString());
			return flag;
		}
		return flag;
	}

	protected ModelService getModelService()
	{
		return modelService;
	}

	@Required
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	public CockpitProperties getCockpitProperties()
	{
		return cockpitProperties;
	}

	@Required
	public void setCockpitProperties(final CockpitProperties cockpitProperties)
	{
		this.cockpitProperties = cockpitProperties;
	}

	@Required
	public void setPermissionFacadeStrategy(final PermissionFacadeStrategy permissionFacadeStrategy)
	{
		this.permissionFacadeStrategy = permissionFacadeStrategy;
	}

	public void setObjectFacade(final ObjectFacade objectFacade)
	{
		this.objectFacade = objectFacade;
	}

	private WidgetInstanceManager getWidgetInstanceManager()
	{
		return widgetInstanceManager;
	}

}
