/**
 *
 */
package de.hybris.platform.marketplaceintegrationbackoffice.utils;

/**
 *
 */
public class MarketplaceIntegrationBackofficeLoggerImpl implements MarketplaceIntegrationBackofficeLogger
{

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.marketplaceintegrationbackoffice.utils.MarketplaceintegrationbackofficeLog#marketplacelog()
	 */
	@Override
	public void log(final String message)
	{
		// YTODO Auto-generated method stub

	}

}
