/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package de.hybris.platform.marketplaceintegrationbackoffice.renderer;

import de.hybris.platform.marketplaceintegrationbackoffice.utils.MarketplaceintegrationbackofficeHttpUtil;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.util.Config;
import de.hybris.platform.util.localization.Localization;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.zkoss.json.JSONObject;
import org.zkoss.util.resource.Labels;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zul.Button;

import com.hybris.backoffice.model.MarketplaceModel;
import com.hybris.backoffice.model.MarketplaceSellerModel;
import com.hybris.backoffice.model.MarketplaceStoreModel;
import com.hybris.backoffice.model.TmallOrderStatusModel;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationEvent;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationUtils;
import com.hybris.cockpitng.core.config.impl.jaxb.editorarea.AbstractPanel;
import com.hybris.cockpitng.core.util.CockpitProperties;
import com.hybris.cockpitng.dataaccess.facades.object.ObjectFacade;
import com.hybris.cockpitng.dataaccess.facades.permissions.PermissionFacadeStrategy;
import com.hybris.cockpitng.dataaccess.facades.type.DataType;
import com.hybris.cockpitng.engine.WidgetInstanceManager;
import com.hybris.cockpitng.widgets.editorarea.renderer.impl.AbstractEditorAreaPanelRenderer;


/**
 *
 */
public class MarketplaceIntegrationInitialRenderer extends AbstractEditorAreaPanelRenderer<MarketplaceStoreModel>
{
	private static final Logger LOG = LoggerFactory.getLogger(MarketplaceIntegrationInitialRenderer.class);
	private final Integer BATCH_SIZE = new Integer(200);

	public static final String MARKETPLACE_ORDER_SYCHRONIZE_PATH = "marketplace.order.sychronize.path";
	public static final String MARKETPLACE_ORDER_INITIAL_PATH = "marketplace.order.initial.path";
	public static final String BACKOFFICE_FORMAT_DATEFORMAT = "backoffice.format.dateformat";

	private ModelService modelService;
	private CockpitProperties cockpitProperties;
	private PermissionFacadeStrategy permissionFacadeStrategy;
	private ObjectFacade objectFacade;
	private WidgetInstanceManager widgetInstanceManager;
	private MarketplaceintegrationbackofficeHttpUtil marketplaceHttpUtil;

	@Override
	public void render(final Component parent, final AbstractPanel panel, final MarketplaceStoreModel data, final DataType type,
			final WidgetInstanceManager widgetInstanceManager)
	{
		this.widgetInstanceManager = widgetInstanceManager;

		final Button loadBtn = new Button(Labels.getLabel("backoffice.button.marketplacestore.initial.download"));
		/*
		 * final Textbox marketplaceName = new Textbox(); final Textbox marketplaceUrl = new Textbox(); final Textbox
		 * marketplaceStoreName = new Textbox();
		 */

		//marketplaceName.addEventHandler(BACKOFFICE_FORMAT_DATEFORMAT, evthd);

		loadBtn.setSclass("initial-load-btn");
		loadBtn.addEventListener(Events.ON_CLICK, event -> {
			// trigger initial order load
				initialOrderDownload(data);
			});
		LOG.debug("The new added renderer MarketplaceIntegrationOrderInitialRenderer has bean loaded successfully");
		parent.appendChild(loadBtn);

	}

	private void initialOrderDownload(final MarketplaceStoreModel model)
	{
		if (null == model.getOrderStartTime())
		{
			NotificationUtils.notifyUserVia(
					Localization.getLocalizedString("type.Marketplacestore." + MarketplaceStoreModel.ORDERSTARTTIME + ".name") + " "
							+ Labels.getLabel("backoffice.field.notfilled"), NotificationEvent.Type.WARNING, "");
			LOG.warn("get order start time is not filled!");
			return;
		}
		else if (null == model.getOrderEndTime())
		{
			NotificationUtils.notifyUserVia(
					Localization.getLocalizedString("type.Marketplacestore." + MarketplaceStoreModel.ORDERENDTIME + ".name") + " "
							+ Labels.getLabel("backoffice.field.notfilled"), NotificationEvent.Type.WARNING, "");
			LOG.warn("get order end time is not filled!");
			return;
		}
		else if (model.getOrderStartTime().after(model.getOrderEndTime()))
		{
			NotificationUtils.notifyUserVia(Labels.getLabel("backoffice.field.timerange.error"), NotificationEvent.Type.WARNING, "");
			LOG.warn("start time is greate than end time!");
			return;
		}
		else if (model.getMarketplace().getTmallOrderStatus().isEmpty() || null == model.getMarketplace().getTmallOrderStatus())
		{
			NotificationUtils.notifyUserVia(
					Localization.getLocalizedString("type.Marketplace." + MarketplaceModel.TMALLORDERSTATUS + ".name") + " "
							+ Labels.getLabel("backoffice.field.notfilled"), NotificationEvent.Type.WARNING, "");
			LOG.warn("order status field is not filled!");
			return;
		}
		if (!StringUtils.isBlank(model.getIntegrationId()) && !model.getAuthorized().booleanValue())
		{
			NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.order.authorization.fail"), NotificationEvent.Type.WARNING,
					"");
			LOG.warn("authorization is expired!");
			return;
		}
		//in order to avoid this value out of date, we only get it from database
		final String integrationId = ((MarketplaceStoreModel) modelService.get(model.getPk())).getIntegrationId();
		final Boolean isAuth = ((MarketplaceStoreModel) modelService.get(model.getPk())).getAuthorized();
		model.setIntegrationId(integrationId);
		model.setAuthorized(isAuth);
		if (null == isAuth || !isAuth.booleanValue())
		{
			NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.order.initorder.unauthed"), NotificationEvent.Type.WARNING,
					"");
			LOG.warn("marketplace store do not authorized, initial download failed!");
			return;
		}

		final MarketplaceSellerModel seller = model.getMarketplaceSeller();
		final MarketplaceModel marketPlace = seller.getMarketplace();

		try
		{
			// Configure and open a connection to the site you will send the
			final String urlStr = marketPlace.getAdapterUrl() + Config.getParameter(MARKETPLACE_ORDER_SYCHRONIZE_PATH)
					+ Config.getParameter(MARKETPLACE_ORDER_INITIAL_PATH) + integrationId;
			final SimpleDateFormat format = new SimpleDateFormat(Config.getParameter(BACKOFFICE_FORMAT_DATEFORMAT));
			final JSONObject jsonObj = new JSONObject();
			jsonObj.put("batchSize", BATCH_SIZE);
			jsonObj.put("status", getOrderStatus(model.getMarketplace().getTmallOrderStatus()));
			jsonObj.put("startCreated", format.format(model.getOrderStartTime()).toString());
			jsonObj.put("endCreated", format.format(model.getOrderEndTime()).toString());
			jsonObj.put("productCatalogVersion", model.getCatalogVersion().getCatalog().getId() + ":"
					+ model.getCatalogVersion().getVersion());
			jsonObj.put("currency", model.getCurrency().getIsocode());
			marketplaceHttpUtil.post(urlStr, jsonObj.toJSONString());
		}
		catch (final IOException e)
		{
			LOG.error(e.toString());
			NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.order.initorder.fail"), NotificationEvent.Type.FAILURE, "");
			return;
		}
		NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.order.initorder.success"), NotificationEvent.Type.SUCCESS, "");
	}

	private String getOrderStatus(final List<TmallOrderStatusModel> statusList)
	{
		final Set<String> statuses = new HashSet<String>();
		for (final TmallOrderStatusModel orderStatus : statusList)
		{
			if (StringUtils.isNotBlank(orderStatus.getCode()))
			{
				statuses.add(orderStatus.getCode());
			}
		}
		return StringUtils.join(statuses, ",");
	}

	protected ModelService getModelService()
	{
		return modelService;
	}

	@Required
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	public CockpitProperties getCockpitProperties()
	{
		return cockpitProperties;
	}

	@Required
	public void setCockpitProperties(final CockpitProperties cockpitProperties)
	{
		this.cockpitProperties = cockpitProperties;
	}

	@Required
	public void setPermissionFacadeStrategy(final PermissionFacadeStrategy permissionFacadeStrategy)
	{
		this.permissionFacadeStrategy = permissionFacadeStrategy;
	}

	public void setObjectFacade(final ObjectFacade objectFacade)
	{
		this.objectFacade = objectFacade;
	}

	private WidgetInstanceManager getWidgetInstanceManager()
	{
		return widgetInstanceManager;
	}

	@Required
	public void setMarketplaceHttpUtil(final MarketplaceintegrationbackofficeHttpUtil marketplaceHttpUtil)
	{
		this.marketplaceHttpUtil = marketplaceHttpUtil;
	}

}
