/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package de.hybris.platform.marketplaceintegrationbackoffice.renderer;


import de.hybris.platform.marketplaceintegration.model.TmallOrderModel;
import de.hybris.platform.marketplaceintegrationbackoffice.utils.MarketplaceintegrationbackofficeRestTemplateUtil;
import de.hybris.platform.ordersplitting.model.ConsignmentModel;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.util.Config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.zkoss.json.JSONObject;
import org.zkoss.util.resource.Labels;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zul.Button;

import com.hybris.backoffice.model.MarketplaceModel;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationEvent;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationUtils;
import com.hybris.cockpitng.core.config.impl.jaxb.editorarea.AbstractPanel;
import com.hybris.cockpitng.core.util.CockpitProperties;
import com.hybris.cockpitng.dataaccess.facades.object.ObjectFacade;
import com.hybris.cockpitng.dataaccess.facades.permissions.PermissionFacadeStrategy;
import com.hybris.cockpitng.dataaccess.facades.type.DataType;
import com.hybris.cockpitng.engine.WidgetInstanceManager;
import com.hybris.cockpitng.widgets.editorarea.renderer.impl.AbstractEditorAreaPanelRenderer;


/**
 *
 */
public class MarketplaceConsignmentConfirmRenderer extends AbstractEditorAreaPanelRenderer<ConsignmentModel>
{
	private static final Logger LOG = LoggerFactory.getLogger(MarketplaceConsignmentConfirmRenderer.class);

	public static final String MARKETPLACE_CONSIGNMENT_SYCHRONIZE_PATH = "marketplace.consignment.sync.path";
	public static final String MARKETPLACE_CONSIGNMENT_CONFIRM_PATH = "marketplace.consignment.confirm.path";
	public static final String MARKETPLACE_CONSIGNMENT_CONFIRM_STATUS = "WAIT_SELLER_SEND_GOODS";

	private ModelService modelService;
	private CockpitProperties cockpitProperties;
	private PermissionFacadeStrategy permissionFacadeStrategy;
	private ObjectFacade objectFacade;
	private WidgetInstanceManager widgetInstanceManager;
	@Autowired
	private MarketplaceintegrationbackofficeRestTemplateUtil marketplaceHttpUtil;

	@Override
	public void render(final Component parent, final AbstractPanel panel, final ConsignmentModel data, final DataType type,
			final WidgetInstanceManager widgetInstanceManager)
	{
		this.widgetInstanceManager = widgetInstanceManager;

		final Button loadBtn = new Button(Labels.getLabel("backoffice.button.marketplace.consignment.confirm"));

		loadBtn.setSclass("initial-load-btn");
		loadBtn.addEventListener(Events.ON_CLICK, event -> {
			// confirm consignment to tmall
				confirmShipConsignment(data);
			});
		LOG.debug("The new added renderer MarketplaceConsignmentConfirmRenderer has bean loaded successfully");
		parent.appendChild(loadBtn);

	}

	private void confirmShipConsignment(final ConsignmentModel model)
	{
		final TmallOrderModel order = (TmallOrderModel) model.getOrder();
		final MarketplaceModel marketPlace = order.getMarketplaceStore().getMarketplace();

		if (!MARKETPLACE_CONSIGNMENT_CONFIRM_STATUS.equals(order.getTmallOrderStatus().getCode()))
		{
			NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.consignment.status.fail"), NotificationEvent.Type.WARNING,
					"");
			LOG.warn("Confirm failed due to order status is not correct!");
			return;
		}

		try
		{
			// Configure and open a connection to the site you will send the
			final String urlStr = marketPlace.getAdapterUrl() + Config.getParameter(MARKETPLACE_CONSIGNMENT_SYCHRONIZE_PATH)
					+ Config.getParameter(MARKETPLACE_CONSIGNMENT_CONFIRM_PATH) + order.getMarketplaceStore().getIntegrationId();
			final JSONObject jsonObj = new JSONObject();
			jsonObj.put("tid", order.getTmallOrderId());
			jsonObj.put("outSid", model.getMarketplaceTrackingID());
			jsonObj.put("companyCode", model.getMarketplaceCarrier().getCode());
			marketplaceHttpUtil.post(urlStr, jsonObj.toJSONString());
		}
		catch (final Exception e)
		{
			LOG.error(e.toString());
			NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.consignment.upload.fail"), NotificationEvent.Type.FAILURE,
					"");
			return;
		}
		NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.consignment.upload.success"), NotificationEvent.Type.SUCCESS,
				"");
	}

	protected ModelService getModelService()
	{
		return modelService;
	}

	@Required
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	public CockpitProperties getCockpitProperties()
	{
		return cockpitProperties;
	}

	@Required
	public void setCockpitProperties(final CockpitProperties cockpitProperties)
	{
		this.cockpitProperties = cockpitProperties;
	}

	@Required
	public void setPermissionFacadeStrategy(final PermissionFacadeStrategy permissionFacadeStrategy)
	{
		this.permissionFacadeStrategy = permissionFacadeStrategy;
	}

	public void setObjectFacade(final ObjectFacade objectFacade)
	{
		this.objectFacade = objectFacade;
	}

	private WidgetInstanceManager getWidgetInstanceManager()
	{
		return widgetInstanceManager;
	}

}
