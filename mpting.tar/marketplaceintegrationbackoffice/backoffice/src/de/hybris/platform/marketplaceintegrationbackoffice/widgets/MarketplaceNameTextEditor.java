package de.hybris.platform.marketplaceintegrationbackoffice.widgets;

import org.apache.commons.lang.StringUtils;
import org.zkoss.util.resource.Labels;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zul.Textbox;

import com.hybris.backoffice.widgets.notificationarea.event.NotificationEvent;
import com.hybris.backoffice.widgets.notificationarea.event.NotificationUtils;
import com.hybris.cockpitng.editors.CockpitEditorRenderer;
import com.hybris.cockpitng.editors.EditorContext;
import com.hybris.cockpitng.editors.EditorListener;


public class MarketplaceNameTextEditor implements CockpitEditorRenderer<String>
{
	@Override
	public void render(final Component parent, final EditorContext<String> context, final EditorListener<String> listener)
	{
		// Create UI component
		final Textbox editorView = new Textbox();

		// Set the initial value
		editorView.setValue(context.getInitialValue());

		// Set the editable state
		if (!context.isEditable())
		{
			if (Executions.getCurrent().getUserAgent().contains("MSIE"))
			{
				editorView.setReadonly(true);
			}
			else
			{
				editorView.setDisabled(true);
			}
		}

		// Handle events
		editorView.addEventListener(Events.ON_CHANGE, new EventListener<Event>()
		{
			@Override
			public void onEvent(final Event event) throws Exception // NOPMD
			{
				handleEvent(editorView, event, listener, context);
			}
		});
		editorView.addEventListener(Events.ON_OK, new EventListener<Event>()
		{
			@Override
			public void onEvent(final Event event) throws Exception // NOPMD
			{
				handleEvent(editorView, event, listener, context);
			}
		});

		// Add the UI component to the component tree
		editorView.setParent(parent);
	}

	/**
	 * Handle a view event on the editor view component.
	 *
	 * @param editorView
	 *           the view component
	 * @param event
	 *           the event to be handled
	 * @param listener
	 *           the editor listener to send change notifications to
	 */
	protected void handleEvent(final Textbox editorView, final Event event, final EditorListener<String> listener,
			final EditorContext<String> context)
	{
		final String result = (String) editorView.getRawValue();
		listener.onValueChanged(StringUtils.isEmpty(result) ? "" : result);
		if (Events.ON_OK.equals(event.getName()))
		{
			listener.onEditorEvent(EditorListener.ENTER_PRESSED);
		}
		if (Events.ON_CHANGE.equals(event.getName()))
		{
			NotificationUtils.notifyUserVia(Labels.getLabel("marketplace.order.authorization.warning.marketplace.name"),
					NotificationEvent.Type.WARNING, "");

		}
	}
}