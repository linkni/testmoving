/**
 *
 */
package de.hybris.platform.marketplaceintegration.interceptor;

import de.hybris.platform.marketplaceintegration.model.MarketplaceOrderModel;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;


/**
 *
 */
public class MarketplaceOrderInterceptor implements PrepareInterceptor<MarketplaceOrderModel>
{

	/**
	 *
	 */
	public MarketplaceOrderInterceptor()
	{
		// YTODO Auto-generated constructor stub
	}


	/*
	 * update store and seller when model is new or modified
	 * 
	 * @see de.hybris.platform.servicelayer.interceptor.PrepareInterceptor#onPrepare(java.lang.Object,
	 * de.hybris.platform.servicelayer.interceptor.InterceptorContext)
	 */
	@Override
	public void onPrepare(final MarketplaceOrderModel orderModel, final InterceptorContext context) throws InterceptorException
	{
		if (context.isModified(orderModel) || context.isNew(orderModel))
		{
			if (null == orderModel.getSeller() && null != orderModel.getMarketplaceStore())
			{
				// if store is not null, then set seller the store's related seller
				orderModel.setSeller(orderModel.getMarketplaceStore().getMarketplaceSeller());
			}
			else if (null != orderModel.getSeller() && null == orderModel.getMarketplaceStore())
			{
				//if store delete then delete related seller
				orderModel.setSeller(null);
			}
		}
	}
}
