/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package de.hybris.platform.marketplaceintegration.jalo;

import com.hybris.backoffice.jalo.MarketplaceSeller;
import com.hybris.backoffice.jalo.MarketplaceStore;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.order.Order;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.marketplaceintegration.jalo.MarketplaceOrder MarketplaceOrder}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedMarketplaceOrder extends Order
{
	/** Qualifier of the <code>MarketplaceOrder.seller</code> attribute **/
	public static final String SELLER = "seller";
	/** Qualifier of the <code>MarketplaceOrder.marketplaceStore</code> attribute **/
	public static final String MARKETPLACESTORE = "marketplaceStore";
	/** Qualifier of the <code>MarketplaceOrder.externalCreatedDate</code> attribute **/
	public static final String EXTERNALCREATEDDATE = "externalCreatedDate";
	/** Qualifier of the <code>MarketplaceOrder.externalModifiedDate</code> attribute **/
	public static final String EXTERNALMODIFIEDDATE = "externalModifiedDate";
	/** Qualifier of the <code>MarketplaceOrder.externalEndDate</code> attribute **/
	public static final String EXTERNALENDDATE = "externalEndDate";
	/** Qualifier of the <code>MarketplaceOrder.title</code> attribute **/
	public static final String TITLE = "title";
	/** Qualifier of the <code>MarketplaceOrder.buyerRemark</code> attribute **/
	public static final String BUYERREMARK = "buyerRemark";
	/** Qualifier of the <code>MarketplaceOrder.sellerMemo</code> attribute **/
	public static final String SELLERMEMO = "sellerMemo";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Order.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(SELLER, AttributeMode.INITIAL);
		tmp.put(MARKETPLACESTORE, AttributeMode.INITIAL);
		tmp.put(EXTERNALCREATEDDATE, AttributeMode.INITIAL);
		tmp.put(EXTERNALMODIFIEDDATE, AttributeMode.INITIAL);
		tmp.put(EXTERNALENDDATE, AttributeMode.INITIAL);
		tmp.put(TITLE, AttributeMode.INITIAL);
		tmp.put(BUYERREMARK, AttributeMode.INITIAL);
		tmp.put(SELLERMEMO, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.buyerRemark</code> attribute.
	 * @return the buyerRemark - buyer's remark, usually a message for seller about delivery time, cost etc.
	 */
	public String getBuyerRemark(final SessionContext ctx)
	{
		return (String)getProperty( ctx, BUYERREMARK);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.buyerRemark</code> attribute.
	 * @return the buyerRemark - buyer's remark, usually a message for seller about delivery time, cost etc.
	 */
	public String getBuyerRemark()
	{
		return getBuyerRemark( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.buyerRemark</code> attribute. 
	 * @param value the buyerRemark - buyer's remark, usually a message for seller about delivery time, cost etc.
	 */
	public void setBuyerRemark(final SessionContext ctx, final String value)
	{
		setProperty(ctx, BUYERREMARK,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.buyerRemark</code> attribute. 
	 * @param value the buyerRemark - buyer's remark, usually a message for seller about delivery time, cost etc.
	 */
	public void setBuyerRemark(final String value)
	{
		setBuyerRemark( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.externalCreatedDate</code> attribute.
	 * @return the externalCreatedDate - Trade Created Date
	 */
	public Date getExternalCreatedDate(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, EXTERNALCREATEDDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.externalCreatedDate</code> attribute.
	 * @return the externalCreatedDate - Trade Created Date
	 */
	public Date getExternalCreatedDate()
	{
		return getExternalCreatedDate( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.externalCreatedDate</code> attribute. 
	 * @param value the externalCreatedDate - Trade Created Date
	 */
	public void setExternalCreatedDate(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, EXTERNALCREATEDDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.externalCreatedDate</code> attribute. 
	 * @param value the externalCreatedDate - Trade Created Date
	 */
	public void setExternalCreatedDate(final Date value)
	{
		setExternalCreatedDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.externalEndDate</code> attribute.
	 * @return the externalEndDate - Trade End Date
	 */
	public Date getExternalEndDate(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, EXTERNALENDDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.externalEndDate</code> attribute.
	 * @return the externalEndDate - Trade End Date
	 */
	public Date getExternalEndDate()
	{
		return getExternalEndDate( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.externalEndDate</code> attribute. 
	 * @param value the externalEndDate - Trade End Date
	 */
	public void setExternalEndDate(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, EXTERNALENDDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.externalEndDate</code> attribute. 
	 * @param value the externalEndDate - Trade End Date
	 */
	public void setExternalEndDate(final Date value)
	{
		setExternalEndDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.externalModifiedDate</code> attribute.
	 * @return the externalModifiedDate - Trade Modified Date
	 */
	public Date getExternalModifiedDate(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, EXTERNALMODIFIEDDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.externalModifiedDate</code> attribute.
	 * @return the externalModifiedDate - Trade Modified Date
	 */
	public Date getExternalModifiedDate()
	{
		return getExternalModifiedDate( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.externalModifiedDate</code> attribute. 
	 * @param value the externalModifiedDate - Trade Modified Date
	 */
	public void setExternalModifiedDate(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, EXTERNALMODIFIEDDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.externalModifiedDate</code> attribute. 
	 * @param value the externalModifiedDate - Trade Modified Date
	 */
	public void setExternalModifiedDate(final Date value)
	{
		setExternalModifiedDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.marketplaceStore</code> attribute.
	 * @return the marketplaceStore - Marketplace Store
	 */
	public MarketplaceStore getMarketplaceStore(final SessionContext ctx)
	{
		return (MarketplaceStore)getProperty( ctx, MARKETPLACESTORE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.marketplaceStore</code> attribute.
	 * @return the marketplaceStore - Marketplace Store
	 */
	public MarketplaceStore getMarketplaceStore()
	{
		return getMarketplaceStore( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.marketplaceStore</code> attribute. 
	 * @param value the marketplaceStore - Marketplace Store
	 */
	public void setMarketplaceStore(final SessionContext ctx, final MarketplaceStore value)
	{
		setProperty(ctx, MARKETPLACESTORE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.marketplaceStore</code> attribute. 
	 * @param value the marketplaceStore - Marketplace Store
	 */
	public void setMarketplaceStore(final MarketplaceStore value)
	{
		setMarketplaceStore( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.seller</code> attribute.
	 * @return the seller - Marketplace Seller
	 */
	public MarketplaceSeller getSeller(final SessionContext ctx)
	{
		return (MarketplaceSeller)getProperty( ctx, SELLER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.seller</code> attribute.
	 * @return the seller - Marketplace Seller
	 */
	public MarketplaceSeller getSeller()
	{
		return getSeller( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.seller</code> attribute. 
	 * @param value the seller - Marketplace Seller
	 */
	public void setSeller(final SessionContext ctx, final MarketplaceSeller value)
	{
		setProperty(ctx, SELLER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.seller</code> attribute. 
	 * @param value the seller - Marketplace Seller
	 */
	public void setSeller(final MarketplaceSeller value)
	{
		setSeller( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.sellerMemo</code> attribute.
	 * @return the sellerMemo - seller's remark
	 */
	public String getSellerMemo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SELLERMEMO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.sellerMemo</code> attribute.
	 * @return the sellerMemo - seller's remark
	 */
	public String getSellerMemo()
	{
		return getSellerMemo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.sellerMemo</code> attribute. 
	 * @param value the sellerMemo - seller's remark
	 */
	public void setSellerMemo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SELLERMEMO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.sellerMemo</code> attribute. 
	 * @param value the sellerMemo - seller's remark
	 */
	public void setSellerMemo(final String value)
	{
		setSellerMemo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.title</code> attribute.
	 * @return the title - Trade ID
	 */
	public String getTitle(final SessionContext ctx)
	{
		return (String)getProperty( ctx, TITLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceOrder.title</code> attribute.
	 * @return the title - Trade ID
	 */
	public String getTitle()
	{
		return getTitle( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.title</code> attribute. 
	 * @param value the title - Trade ID
	 */
	public void setTitle(final SessionContext ctx, final String value)
	{
		setProperty(ctx, TITLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceOrder.title</code> attribute. 
	 * @param value the title - Trade ID
	 */
	public void setTitle(final String value)
	{
		setTitle( getSession().getSessionContext(), value );
	}
	
}
