/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package de.hybris.platform.marketplaceintegration.jalo;

import com.hybris.backoffice.jalo.Marketplace;
import com.hybris.backoffice.jalo.MarketplaceSeller;
import com.hybris.backoffice.jalo.MarketplaceStore;
import com.hybris.backoffice.jalo.TmallOrderStatus;
import com.hybris.backoffice.jalo.TmallOrderType;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import de.hybris.platform.marketplaceintegration.jalo.TmallCustomer;
import de.hybris.platform.marketplaceintegration.jalo.TmallOrder;
import de.hybris.platform.marketplaceintegration.jalo.TmallOrderEntry;
import de.hybris.platform.store.BaseStore;
import de.hybris.platform.util.OneToManyHandler;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Generated class for type <code>MarketplaceintegrationManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedMarketplaceintegrationManager extends Extension
{
	/**
	* {@link OneToManyHandler} for handling 1:n MARKETPLACESTORES's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<MarketplaceStore> BASESTORE2STORERELMARKETPLACESTORESHANDLER = new OneToManyHandler<MarketplaceStore>(
	MarketplaceintegrationConstants.TC.MARKETPLACESTORE,
	false,
	"baseStore",
	"baseStorePOS",
	true,
	true,
	CollectionType.LIST
	);
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	public Marketplace createMarketplace(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.MARKETPLACE );
			return (Marketplace)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating Marketplace : "+e.getMessage(), 0 );
		}
	}
	
	public Marketplace createMarketplace(final Map attributeValues)
	{
		return createMarketplace( getSession().getSessionContext(), attributeValues );
	}
	
	public MarketplaceSeller createMarketplaceSeller(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.MARKETPLACESELLER );
			return (MarketplaceSeller)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating MarketplaceSeller : "+e.getMessage(), 0 );
		}
	}
	
	public MarketplaceSeller createMarketplaceSeller(final Map attributeValues)
	{
		return createMarketplaceSeller( getSession().getSessionContext(), attributeValues );
	}
	
	public MarketplaceStore createMarketplaceStore(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.MARKETPLACESTORE );
			return (MarketplaceStore)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating MarketplaceStore : "+e.getMessage(), 0 );
		}
	}
	
	public MarketplaceStore createMarketplaceStore(final Map attributeValues)
	{
		return createMarketplaceStore( getSession().getSessionContext(), attributeValues );
	}
	
	public TmallCustomer createTmallCustomer(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.TMALLCUSTOMER );
			return (TmallCustomer)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating TmallCustomer : "+e.getMessage(), 0 );
		}
	}
	
	public TmallCustomer createTmallCustomer(final Map attributeValues)
	{
		return createTmallCustomer( getSession().getSessionContext(), attributeValues );
	}
	
	public TmallOrder createTmallOrder(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.TMALLORDER );
			return (TmallOrder)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating TmallOrder : "+e.getMessage(), 0 );
		}
	}
	
	public TmallOrder createTmallOrder(final Map attributeValues)
	{
		return createTmallOrder( getSession().getSessionContext(), attributeValues );
	}
	
	public TmallOrderEntry createTmallOrderEntry(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.TMALLORDERENTRY );
			return (TmallOrderEntry)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating TmallOrderEntry : "+e.getMessage(), 0 );
		}
	}
	
	public TmallOrderEntry createTmallOrderEntry(final Map attributeValues)
	{
		return createTmallOrderEntry( getSession().getSessionContext(), attributeValues );
	}
	
	public TmallOrderStatus createTmallOrderStatus(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.TMALLORDERSTATUS );
			return (TmallOrderStatus)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating TmallOrderStatus : "+e.getMessage(), 0 );
		}
	}
	
	public TmallOrderStatus createTmallOrderStatus(final Map attributeValues)
	{
		return createTmallOrderStatus( getSession().getSessionContext(), attributeValues );
	}
	
	public TmallOrderType createTmallOrderType(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( MarketplaceintegrationConstants.TC.TMALLORDERTYPE );
			return (TmallOrderType)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating TmallOrderType : "+e.getMessage(), 0 );
		}
	}
	
	public TmallOrderType createTmallOrderType(final Map attributeValues)
	{
		return createTmallOrderType( getSession().getSessionContext(), attributeValues );
	}
	
	@Override
	public String getName()
	{
		return MarketplaceintegrationConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.marketplaceStores</code> attribute.
	 * @return the marketplaceStores
	 */
	public List<MarketplaceStore> getMarketplaceStores(final SessionContext ctx, final BaseStore item)
	{
		return (List<MarketplaceStore>)BASESTORE2STORERELMARKETPLACESTORESHANDLER.getValues( ctx, item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.marketplaceStores</code> attribute.
	 * @return the marketplaceStores
	 */
	public List<MarketplaceStore> getMarketplaceStores(final BaseStore item)
	{
		return getMarketplaceStores( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.marketplaceStores</code> attribute. 
	 * @param value the marketplaceStores
	 */
	public void setMarketplaceStores(final SessionContext ctx, final BaseStore item, final List<MarketplaceStore> value)
	{
		BASESTORE2STORERELMARKETPLACESTORESHANDLER.setValues( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.marketplaceStores</code> attribute. 
	 * @param value the marketplaceStores
	 */
	public void setMarketplaceStores(final BaseStore item, final List<MarketplaceStore> value)
	{
		setMarketplaceStores( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to marketplaceStores. 
	 * @param value the item to add to marketplaceStores
	 */
	public void addToMarketplaceStores(final SessionContext ctx, final BaseStore item, final MarketplaceStore value)
	{
		BASESTORE2STORERELMARKETPLACESTORESHANDLER.addValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to marketplaceStores. 
	 * @param value the item to add to marketplaceStores
	 */
	public void addToMarketplaceStores(final BaseStore item, final MarketplaceStore value)
	{
		addToMarketplaceStores( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from marketplaceStores. 
	 * @param value the item to remove from marketplaceStores
	 */
	public void removeFromMarketplaceStores(final SessionContext ctx, final BaseStore item, final MarketplaceStore value)
	{
		BASESTORE2STORERELMARKETPLACESTORESHANDLER.removeValue( ctx, item, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from marketplaceStores. 
	 * @param value the item to remove from marketplaceStores
	 */
	public void removeFromMarketplaceStores(final BaseStore item, final MarketplaceStore value)
	{
		removeFromMarketplaceStores( getSession().getSessionContext(), item, value );
	}
	
}
