/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package de.hybris.platform.marketplaceintegration.jalo;

import com.hybris.backoffice.jalo.TmallOrderStatus;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.order.OrderEntry;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.marketplaceintegration.jalo.TmallOrderEntry TmallOrderEntry}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedTmallOrderEntry extends OrderEntry
{
	/** Qualifier of the <code>TmallOrderEntry.refundStatus</code> attribute **/
	public static final String REFUNDSTATUS = "refundStatus";
	/** Qualifier of the <code>TmallOrderEntry.oid</code> attribute **/
	public static final String OID = "oid";
	/** Qualifier of the <code>TmallOrderEntry.endTime</code> attribute **/
	public static final String ENDTIME = "endTime";
	/** Qualifier of the <code>TmallOrderEntry.entryStatus</code> attribute **/
	public static final String ENTRYSTATUS = "entryStatus";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(OrderEntry.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(REFUNDSTATUS, AttributeMode.INITIAL);
		tmp.put(OID, AttributeMode.INITIAL);
		tmp.put(ENDTIME, AttributeMode.INITIAL);
		tmp.put(ENTRYSTATUS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.endTime</code> attribute.
	 * @return the endTime
	 */
	public Date getEndTime(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, ENDTIME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.endTime</code> attribute.
	 * @return the endTime
	 */
	public Date getEndTime()
	{
		return getEndTime( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.endTime</code> attribute. 
	 * @param value the endTime
	 */
	public void setEndTime(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, ENDTIME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.endTime</code> attribute. 
	 * @param value the endTime
	 */
	public void setEndTime(final Date value)
	{
		setEndTime( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.entryStatus</code> attribute.
	 * @return the entryStatus - Tmall Order Entry Status
	 */
	public TmallOrderStatus getEntryStatus(final SessionContext ctx)
	{
		return (TmallOrderStatus)getProperty( ctx, ENTRYSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.entryStatus</code> attribute.
	 * @return the entryStatus - Tmall Order Entry Status
	 */
	public TmallOrderStatus getEntryStatus()
	{
		return getEntryStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.entryStatus</code> attribute. 
	 * @param value the entryStatus - Tmall Order Entry Status
	 */
	public void setEntryStatus(final SessionContext ctx, final TmallOrderStatus value)
	{
		setProperty(ctx, ENTRYSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.entryStatus</code> attribute. 
	 * @param value the entryStatus - Tmall Order Entry Status
	 */
	public void setEntryStatus(final TmallOrderStatus value)
	{
		setEntryStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.oid</code> attribute.
	 * @return the oid
	 */
	public String getOid(final SessionContext ctx)
	{
		return (String)getProperty( ctx, OID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.oid</code> attribute.
	 * @return the oid
	 */
	public String getOid()
	{
		return getOid( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.oid</code> attribute. 
	 * @param value the oid
	 */
	public void setOid(final SessionContext ctx, final String value)
	{
		setProperty(ctx, OID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.oid</code> attribute. 
	 * @param value the oid
	 */
	public void setOid(final String value)
	{
		setOid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.refundStatus</code> attribute.
	 * @return the refundStatus
	 */
	public String getRefundStatus(final SessionContext ctx)
	{
		return (String)getProperty( ctx, REFUNDSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrderEntry.refundStatus</code> attribute.
	 * @return the refundStatus
	 */
	public String getRefundStatus()
	{
		return getRefundStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.refundStatus</code> attribute. 
	 * @param value the refundStatus
	 */
	public void setRefundStatus(final SessionContext ctx, final String value)
	{
		setProperty(ctx, REFUNDSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrderEntry.refundStatus</code> attribute. 
	 * @param value the refundStatus
	 */
	public void setRefundStatus(final String value)
	{
		setRefundStatus( getSession().getSessionContext(), value );
	}
	
}
