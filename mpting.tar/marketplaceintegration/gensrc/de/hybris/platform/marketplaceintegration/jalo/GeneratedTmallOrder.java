/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package de.hybris.platform.marketplaceintegration.jalo;

import com.hybris.backoffice.jalo.TmallOrderStatus;
import com.hybris.backoffice.jalo.TmallOrderType;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.order.AbstractOrderEntry;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import de.hybris.platform.marketplaceintegration.jalo.MarketplaceOrder;
import de.hybris.platform.marketplaceintegration.jalo.TmallOrderEntry;
import de.hybris.platform.util.OneToManyHandler;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.marketplaceintegration.jalo.TmallOrder TmallOrder}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedTmallOrder extends MarketplaceOrder
{
	/** Qualifier of the <code>TmallOrder.tmallOrderType</code> attribute **/
	public static final String TMALLORDERTYPE = "tmallOrderType";
	/** Qualifier of the <code>TmallOrder.tmallOrderStatus</code> attribute **/
	public static final String TMALLORDERSTATUS = "tmallOrderStatus";
	/** Qualifier of the <code>TmallOrder.tmallOrderId</code> attribute **/
	public static final String TMALLORDERID = "tmallOrderId";
	/** Qualifier of the <code>TmallOrder.alipayTransId</code> attribute **/
	public static final String ALIPAYTRANSID = "alipayTransId";
	/**
	* {@link OneToManyHandler} for handling 1:n ENTRIES's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<AbstractOrderEntry> ENTRIESHANDLER = new OneToManyHandler<AbstractOrderEntry>(
	MarketplaceintegrationConstants.TC.TMALLORDERENTRY,
	true,
	"order",
	"entryNumber",
	false,
	true,
	CollectionType.LIST
	);
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(MarketplaceOrder.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(TMALLORDERTYPE, AttributeMode.INITIAL);
		tmp.put(TMALLORDERSTATUS, AttributeMode.INITIAL);
		tmp.put(TMALLORDERID, AttributeMode.INITIAL);
		tmp.put(ALIPAYTRANSID, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.alipayTransId</code> attribute.
	 * @return the alipayTransId - Alipay Transaction ID (alipayNo)
	 */
	public String getAlipayTransId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ALIPAYTRANSID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.alipayTransId</code> attribute.
	 * @return the alipayTransId - Alipay Transaction ID (alipayNo)
	 */
	public String getAlipayTransId()
	{
		return getAlipayTransId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.alipayTransId</code> attribute. 
	 * @param value the alipayTransId - Alipay Transaction ID (alipayNo)
	 */
	public void setAlipayTransId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ALIPAYTRANSID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.alipayTransId</code> attribute. 
	 * @param value the alipayTransId - Alipay Transaction ID (alipayNo)
	 */
	public void setAlipayTransId(final String value)
	{
		setAlipayTransId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.entries</code> attribute.
	 * @return the entries
	 */
	public List<AbstractOrderEntry> getEntries(final SessionContext ctx)
	{
		return (List<AbstractOrderEntry>)ENTRIESHANDLER.getValues( ctx, this );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.entries</code> attribute.
	 * @return the entries
	 */
	public List<AbstractOrderEntry> getEntries()
	{
		return getEntries( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.entries</code> attribute. 
	 * @param value the entries
	 */
	public void setEntries(final SessionContext ctx, final List<AbstractOrderEntry> value)
	{
		ENTRIESHANDLER.setValues( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.entries</code> attribute. 
	 * @param value the entries
	 */
	public void setEntries(final List<AbstractOrderEntry> value)
	{
		setEntries( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to entries. 
	 * @param value the item to add to entries
	 */
	public void addToEntries(final SessionContext ctx, final TmallOrderEntry value)
	{
		ENTRIESHANDLER.addValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to entries. 
	 * @param value the item to add to entries
	 */
	public void addToEntries(final TmallOrderEntry value)
	{
		addToEntries( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from entries. 
	 * @param value the item to remove from entries
	 */
	public void removeFromEntries(final SessionContext ctx, final TmallOrderEntry value)
	{
		ENTRIESHANDLER.removeValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from entries. 
	 * @param value the item to remove from entries
	 */
	public void removeFromEntries(final TmallOrderEntry value)
	{
		removeFromEntries( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.tmallOrderId</code> attribute.
	 * @return the tmallOrderId - Tmall Trade ID
	 */
	public String getTmallOrderId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, TMALLORDERID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.tmallOrderId</code> attribute.
	 * @return the tmallOrderId - Tmall Trade ID
	 */
	public String getTmallOrderId()
	{
		return getTmallOrderId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.tmallOrderId</code> attribute. 
	 * @param value the tmallOrderId - Tmall Trade ID
	 */
	public void setTmallOrderId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, TMALLORDERID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.tmallOrderId</code> attribute. 
	 * @param value the tmallOrderId - Tmall Trade ID
	 */
	public void setTmallOrderId(final String value)
	{
		setTmallOrderId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.tmallOrderStatus</code> attribute.
	 * @return the tmallOrderStatus - Tmall Order Status
	 */
	public TmallOrderStatus getTmallOrderStatus(final SessionContext ctx)
	{
		return (TmallOrderStatus)getProperty( ctx, TMALLORDERSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.tmallOrderStatus</code> attribute.
	 * @return the tmallOrderStatus - Tmall Order Status
	 */
	public TmallOrderStatus getTmallOrderStatus()
	{
		return getTmallOrderStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.tmallOrderStatus</code> attribute. 
	 * @param value the tmallOrderStatus - Tmall Order Status
	 */
	public void setTmallOrderStatus(final SessionContext ctx, final TmallOrderStatus value)
	{
		setProperty(ctx, TMALLORDERSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.tmallOrderStatus</code> attribute. 
	 * @param value the tmallOrderStatus - Tmall Order Status
	 */
	public void setTmallOrderStatus(final TmallOrderStatus value)
	{
		setTmallOrderStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.tmallOrderType</code> attribute.
	 * @return the tmallOrderType - Tmall order Type
	 */
	public TmallOrderType getTmallOrderType(final SessionContext ctx)
	{
		return (TmallOrderType)getProperty( ctx, TMALLORDERTYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TmallOrder.tmallOrderType</code> attribute.
	 * @return the tmallOrderType - Tmall order Type
	 */
	public TmallOrderType getTmallOrderType()
	{
		return getTmallOrderType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.tmallOrderType</code> attribute. 
	 * @param value the tmallOrderType - Tmall order Type
	 */
	public void setTmallOrderType(final SessionContext ctx, final TmallOrderType value)
	{
		setProperty(ctx, TMALLORDERTYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TmallOrder.tmallOrderType</code> attribute. 
	 * @param value the tmallOrderType - Tmall order Type
	 */
	public void setTmallOrderType(final TmallOrderType value)
	{
		setTmallOrderType( getSession().getSessionContext(), value );
	}
	
}
