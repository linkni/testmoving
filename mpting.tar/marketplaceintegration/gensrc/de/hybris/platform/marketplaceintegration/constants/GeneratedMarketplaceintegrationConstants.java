/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package de.hybris.platform.marketplaceintegration.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedMarketplaceintegrationConstants
{
	public static final String EXTENSIONNAME = "marketplaceintegration";
	public static class TC
	{
		public static final String MARKETPLACE = "Marketplace".intern();
		public static final String MARKETPLACEORDER = "MarketplaceOrder".intern();
		public static final String MARKETPLACESELLER = "MarketplaceSeller".intern();
		public static final String MARKETPLACESTORE = "MarketplaceStore".intern();
		public static final String TMALLCUSTOMER = "TmallCustomer".intern();
		public static final String TMALLORDER = "TmallOrder".intern();
		public static final String TMALLORDERENTRY = "TmallOrderEntry".intern();
		public static final String TMALLORDERSTATUS = "TmallOrderStatus".intern();
		public static final String TMALLORDERTYPE = "TmallOrderType".intern();
	}
	public static class Attributes
	{
		public static class BaseStore
		{
			public static final String MARKETPLACESTORES = "marketplaceStores".intern();
		}
	}
	public static class Relations
	{
		public static final String BASESTORE2STOREREL = "BaseStore2StoreRel".intern();
		public static final String MARKETPLACESTORE2SELLERREL = "MarketplaceStore2SellerRel".intern();
		public static final String MARKETPLACESTORE2TMALLORDERSTATUSREL = "MarketplaceStore2TmallOrderStatusRel".intern();
	}
	
	protected GeneratedMarketplaceintegrationConstants()
	{
		// private constructor
	}
	
	
}
