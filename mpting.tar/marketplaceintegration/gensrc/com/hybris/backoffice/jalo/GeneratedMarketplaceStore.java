/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package com.hybris.backoffice.jalo;

import com.hybris.backoffice.jalo.Marketplace;
import com.hybris.backoffice.jalo.MarketplaceSeller;
import de.hybris.platform.catalog.jalo.CatalogVersion;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.Currency;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import de.hybris.platform.store.BaseStore;
import de.hybris.platform.util.BidirectionalOneToManyHandler;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.hybris.backoffice.jalo.MarketplaceStore MarketplaceStore}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedMarketplaceStore extends GenericItem
{
	/** Qualifier of the <code>MarketplaceStore.name</code> attribute **/
	public static final String NAME = "name";
	/** Qualifier of the <code>MarketplaceStore.orderStartTime</code> attribute **/
	public static final String ORDERSTARTTIME = "orderStartTime";
	/** Qualifier of the <code>MarketplaceStore.orderEndTime</code> attribute **/
	public static final String ORDERENDTIME = "orderEndTime";
	/** Qualifier of the <code>MarketplaceStore.integrationId</code> attribute **/
	public static final String INTEGRATIONID = "integrationId";
	/** Qualifier of the <code>MarketplaceStore.authorized</code> attribute **/
	public static final String AUTHORIZED = "authorized";
	/** Qualifier of the <code>MarketplaceStore.subscribeorder</code> attribute **/
	public static final String SUBSCRIBEORDER = "subscribeorder";
	/** Qualifier of the <code>MarketplaceStore.marketplace</code> attribute **/
	public static final String MARKETPLACE = "marketplace";
	/** Qualifier of the <code>MarketplaceStore.currency</code> attribute **/
	public static final String CURRENCY = "currency";
	/** Qualifier of the <code>MarketplaceStore.catalogVersion</code> attribute **/
	public static final String CATALOGVERSION = "catalogVersion";
	/** Qualifier of the <code>MarketplaceStore.url</code> attribute **/
	public static final String URL = "url";
	/** Qualifier of the <code>MarketplaceStore.baseStorePOS</code> attribute **/
	public static final String BASESTOREPOS = "baseStorePOS";
	/** Qualifier of the <code>MarketplaceStore.baseStore</code> attribute **/
	public static final String BASESTORE = "baseStore";
	/** Qualifier of the <code>MarketplaceStore.marketplaceSeller</code> attribute **/
	public static final String MARKETPLACESELLER = "marketplaceSeller";
	/**
	* {@link BidirectionalOneToManyHandler} for handling 1:n BASESTORE's relation attributes from 'one' side.
	**/
	protected static final BidirectionalOneToManyHandler<GeneratedMarketplaceStore> BASESTOREHANDLER = new BidirectionalOneToManyHandler<GeneratedMarketplaceStore>(
	MarketplaceintegrationConstants.TC.MARKETPLACESTORE,
	false,
	"baseStore",
	"baseStorePOS",
	true,
	true,
	CollectionType.LIST
	);
	/**
	* {@link BidirectionalOneToManyHandler} for handling 1:n MARKETPLACESELLER's relation attributes from 'one' side.
	**/
	protected static final BidirectionalOneToManyHandler<GeneratedMarketplaceStore> MARKETPLACESELLERHANDLER = new BidirectionalOneToManyHandler<GeneratedMarketplaceStore>(
	MarketplaceintegrationConstants.TC.MARKETPLACESTORE,
	false,
	"marketplaceSeller",
	null,
	false,
	true,
	CollectionType.COLLECTION
	);
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(NAME, AttributeMode.INITIAL);
		tmp.put(ORDERSTARTTIME, AttributeMode.INITIAL);
		tmp.put(ORDERENDTIME, AttributeMode.INITIAL);
		tmp.put(INTEGRATIONID, AttributeMode.INITIAL);
		tmp.put(AUTHORIZED, AttributeMode.INITIAL);
		tmp.put(SUBSCRIBEORDER, AttributeMode.INITIAL);
		tmp.put(MARKETPLACE, AttributeMode.INITIAL);
		tmp.put(CURRENCY, AttributeMode.INITIAL);
		tmp.put(CATALOGVERSION, AttributeMode.INITIAL);
		tmp.put(URL, AttributeMode.INITIAL);
		tmp.put(BASESTOREPOS, AttributeMode.INITIAL);
		tmp.put(BASESTORE, AttributeMode.INITIAL);
		tmp.put(MARKETPLACESELLER, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.authorized</code> attribute.
	 * @return the authorized - Flag to indicate whether authorized or not
	 */
	public Boolean isAuthorized(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, AUTHORIZED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.authorized</code> attribute.
	 * @return the authorized - Flag to indicate whether authorized or not
	 */
	public Boolean isAuthorized()
	{
		return isAuthorized( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.authorized</code> attribute. 
	 * @return the authorized - Flag to indicate whether authorized or not
	 */
	public boolean isAuthorizedAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isAuthorized( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.authorized</code> attribute. 
	 * @return the authorized - Flag to indicate whether authorized or not
	 */
	public boolean isAuthorizedAsPrimitive()
	{
		return isAuthorizedAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.authorized</code> attribute. 
	 * @param value the authorized - Flag to indicate whether authorized or not
	 */
	public void setAuthorized(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, AUTHORIZED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.authorized</code> attribute. 
	 * @param value the authorized - Flag to indicate whether authorized or not
	 */
	public void setAuthorized(final Boolean value)
	{
		setAuthorized( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.authorized</code> attribute. 
	 * @param value the authorized - Flag to indicate whether authorized or not
	 */
	public void setAuthorized(final SessionContext ctx, final boolean value)
	{
		setAuthorized( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.authorized</code> attribute. 
	 * @param value the authorized - Flag to indicate whether authorized or not
	 */
	public void setAuthorized(final boolean value)
	{
		setAuthorized( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.baseStore</code> attribute.
	 * @return the baseStore
	 */
	public BaseStore getBaseStore(final SessionContext ctx)
	{
		return (BaseStore)getProperty( ctx, BASESTORE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.baseStore</code> attribute.
	 * @return the baseStore
	 */
	public BaseStore getBaseStore()
	{
		return getBaseStore( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.baseStore</code> attribute. 
	 * @param value the baseStore
	 */
	public void setBaseStore(final SessionContext ctx, final BaseStore value)
	{
		BASESTOREHANDLER.addValue( ctx, value, this  );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.baseStore</code> attribute. 
	 * @param value the baseStore
	 */
	public void setBaseStore(final BaseStore value)
	{
		setBaseStore( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.baseStorePOS</code> attribute.
	 * @return the baseStorePOS
	 */
	 Integer getBaseStorePOS(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, BASESTOREPOS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.baseStorePOS</code> attribute.
	 * @return the baseStorePOS
	 */
	 Integer getBaseStorePOS()
	{
		return getBaseStorePOS( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.baseStorePOS</code> attribute. 
	 * @return the baseStorePOS
	 */
	 int getBaseStorePOSAsPrimitive(final SessionContext ctx)
	{
		Integer value = getBaseStorePOS( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.baseStorePOS</code> attribute. 
	 * @return the baseStorePOS
	 */
	 int getBaseStorePOSAsPrimitive()
	{
		return getBaseStorePOSAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.baseStorePOS</code> attribute. 
	 * @param value the baseStorePOS
	 */
	 void setBaseStorePOS(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, BASESTOREPOS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.baseStorePOS</code> attribute. 
	 * @param value the baseStorePOS
	 */
	 void setBaseStorePOS(final Integer value)
	{
		setBaseStorePOS( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.baseStorePOS</code> attribute. 
	 * @param value the baseStorePOS
	 */
	 void setBaseStorePOS(final SessionContext ctx, final int value)
	{
		setBaseStorePOS( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.baseStorePOS</code> attribute. 
	 * @param value the baseStorePOS
	 */
	 void setBaseStorePOS(final int value)
	{
		setBaseStorePOS( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.catalogVersion</code> attribute.
	 * @return the catalogVersion - The target product catalog version (ONLINE version required)
	 */
	public CatalogVersion getCatalogVersion(final SessionContext ctx)
	{
		return (CatalogVersion)getProperty( ctx, CATALOGVERSION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.catalogVersion</code> attribute.
	 * @return the catalogVersion - The target product catalog version (ONLINE version required)
	 */
	public CatalogVersion getCatalogVersion()
	{
		return getCatalogVersion( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.catalogVersion</code> attribute. 
	 * @param value the catalogVersion - The target product catalog version (ONLINE version required)
	 */
	public void setCatalogVersion(final SessionContext ctx, final CatalogVersion value)
	{
		setProperty(ctx, CATALOGVERSION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.catalogVersion</code> attribute. 
	 * @param value the catalogVersion - The target product catalog version (ONLINE version required)
	 */
	public void setCatalogVersion(final CatalogVersion value)
	{
		setCatalogVersion( getSession().getSessionContext(), value );
	}
	
	@Override
	protected Item createItem(final SessionContext ctx, final ComposedType type, final ItemAttributeMap allAttributes) throws JaloBusinessException
	{
		BASESTOREHANDLER.newInstance(ctx, allAttributes);
		MARKETPLACESELLERHANDLER.newInstance(ctx, allAttributes);
		return super.createItem( ctx, type, allAttributes );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.currency</code> attribute.
	 * @return the currency - The currency context
	 */
	public Currency getCurrency(final SessionContext ctx)
	{
		return (Currency)getProperty( ctx, CURRENCY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.currency</code> attribute.
	 * @return the currency - The currency context
	 */
	public Currency getCurrency()
	{
		return getCurrency( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.currency</code> attribute. 
	 * @param value the currency - The currency context
	 */
	public void setCurrency(final SessionContext ctx, final Currency value)
	{
		setProperty(ctx, CURRENCY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.currency</code> attribute. 
	 * @param value the currency - The currency context
	 */
	public void setCurrency(final Currency value)
	{
		setCurrency( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.integrationId</code> attribute.
	 * @return the integrationId - Integration Id
	 */
	public String getIntegrationId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, INTEGRATIONID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.integrationId</code> attribute.
	 * @return the integrationId - Integration Id
	 */
	public String getIntegrationId()
	{
		return getIntegrationId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.integrationId</code> attribute. 
	 * @param value the integrationId - Integration Id
	 */
	public void setIntegrationId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, INTEGRATIONID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.integrationId</code> attribute. 
	 * @param value the integrationId - Integration Id
	 */
	public void setIntegrationId(final String value)
	{
		setIntegrationId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.marketplace</code> attribute.
	 * @return the marketplace - Marketplace
	 */
	public Marketplace getMarketplace(final SessionContext ctx)
	{
		return (Marketplace)getProperty( ctx, MARKETPLACE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.marketplace</code> attribute.
	 * @return the marketplace - Marketplace
	 */
	public Marketplace getMarketplace()
	{
		return getMarketplace( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.marketplace</code> attribute. 
	 * @param value the marketplace - Marketplace
	 */
	public void setMarketplace(final SessionContext ctx, final Marketplace value)
	{
		setProperty(ctx, MARKETPLACE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.marketplace</code> attribute. 
	 * @param value the marketplace - Marketplace
	 */
	public void setMarketplace(final Marketplace value)
	{
		setMarketplace( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.marketplaceSeller</code> attribute.
	 * @return the marketplaceSeller
	 */
	public MarketplaceSeller getMarketplaceSeller(final SessionContext ctx)
	{
		return (MarketplaceSeller)getProperty( ctx, MARKETPLACESELLER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.marketplaceSeller</code> attribute.
	 * @return the marketplaceSeller
	 */
	public MarketplaceSeller getMarketplaceSeller()
	{
		return getMarketplaceSeller( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.marketplaceSeller</code> attribute. 
	 * @param value the marketplaceSeller
	 */
	public void setMarketplaceSeller(final SessionContext ctx, final MarketplaceSeller value)
	{
		MARKETPLACESELLERHANDLER.addValue( ctx, value, this  );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.marketplaceSeller</code> attribute. 
	 * @param value the marketplaceSeller
	 */
	public void setMarketplaceSeller(final MarketplaceSeller value)
	{
		setMarketplaceSeller( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.name</code> attribute.
	 * @return the name - Marketplace Store Name
	 */
	public String getName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.name</code> attribute.
	 * @return the name - Marketplace Store Name
	 */
	public String getName()
	{
		return getName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.name</code> attribute. 
	 * @param value the name - Marketplace Store Name
	 */
	public void setName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.name</code> attribute. 
	 * @param value the name - Marketplace Store Name
	 */
	public void setName(final String value)
	{
		setName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.orderEndTime</code> attribute.
	 * @return the orderEndTime - Order End Time
	 */
	public Date getOrderEndTime(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, ORDERENDTIME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.orderEndTime</code> attribute.
	 * @return the orderEndTime - Order End Time
	 */
	public Date getOrderEndTime()
	{
		return getOrderEndTime( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.orderEndTime</code> attribute. 
	 * @param value the orderEndTime - Order End Time
	 */
	public void setOrderEndTime(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, ORDERENDTIME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.orderEndTime</code> attribute. 
	 * @param value the orderEndTime - Order End Time
	 */
	public void setOrderEndTime(final Date value)
	{
		setOrderEndTime( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.orderStartTime</code> attribute.
	 * @return the orderStartTime - Order Start Time
	 */
	public Date getOrderStartTime(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, ORDERSTARTTIME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.orderStartTime</code> attribute.
	 * @return the orderStartTime - Order Start Time
	 */
	public Date getOrderStartTime()
	{
		return getOrderStartTime( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.orderStartTime</code> attribute. 
	 * @param value the orderStartTime - Order Start Time
	 */
	public void setOrderStartTime(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, ORDERSTARTTIME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.orderStartTime</code> attribute. 
	 * @param value the orderStartTime - Order Start Time
	 */
	public void setOrderStartTime(final Date value)
	{
		setOrderStartTime( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.subscribeorder</code> attribute.
	 * @return the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public Boolean isSubscribeorder(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, SUBSCRIBEORDER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.subscribeorder</code> attribute.
	 * @return the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public Boolean isSubscribeorder()
	{
		return isSubscribeorder( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.subscribeorder</code> attribute. 
	 * @return the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public boolean isSubscribeorderAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isSubscribeorder( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.subscribeorder</code> attribute. 
	 * @return the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public boolean isSubscribeorderAsPrimitive()
	{
		return isSubscribeorderAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.subscribeorder</code> attribute. 
	 * @param value the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public void setSubscribeorder(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, SUBSCRIBEORDER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.subscribeorder</code> attribute. 
	 * @param value the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public void setSubscribeorder(final Boolean value)
	{
		setSubscribeorder( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.subscribeorder</code> attribute. 
	 * @param value the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public void setSubscribeorder(final SessionContext ctx, final boolean value)
	{
		setSubscribeorder( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.subscribeorder</code> attribute. 
	 * @param value the subscribeorder - Flag to indicate whether subscribed or not
	 */
	public void setSubscribeorder(final boolean value)
	{
		setSubscribeorder( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.url</code> attribute.
	 * @return the url - Store URL
	 */
	public String getUrl(final SessionContext ctx)
	{
		return (String)getProperty( ctx, URL);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceStore.url</code> attribute.
	 * @return the url - Store URL
	 */
	public String getUrl()
	{
		return getUrl( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.url</code> attribute. 
	 * @param value the url - Store URL
	 */
	public void setUrl(final SessionContext ctx, final String value)
	{
		setProperty(ctx, URL,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceStore.url</code> attribute. 
	 * @param value the url - Store URL
	 */
	public void setUrl(final String value)
	{
		setUrl( getSession().getSessionContext(), value );
	}
	
}
