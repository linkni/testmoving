/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package com.hybris.backoffice.jalo;

import com.hybris.backoffice.jalo.Marketplace;
import com.hybris.backoffice.jalo.MarketplaceStore;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import de.hybris.platform.store.BaseStore;
import de.hybris.platform.util.OneToManyHandler;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.hybris.backoffice.jalo.MarketplaceSeller MarketplaceSeller}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedMarketplaceSeller extends GenericItem
{
	/** Qualifier of the <code>MarketplaceSeller.name</code> attribute **/
	public static final String NAME = "name";
	/** Qualifier of the <code>MarketplaceSeller.baseStore</code> attribute **/
	public static final String BASESTORE = "baseStore";
	/** Qualifier of the <code>MarketplaceSeller.marketplace</code> attribute **/
	public static final String MARKETPLACE = "marketplace";
	/** Qualifier of the <code>MarketplaceSeller.marketplaceStores</code> attribute **/
	public static final String MARKETPLACESTORES = "marketplaceStores";
	/**
	* {@link OneToManyHandler} for handling 1:n MARKETPLACESTORES's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<MarketplaceStore> MARKETPLACESTORESHANDLER = new OneToManyHandler<MarketplaceStore>(
	MarketplaceintegrationConstants.TC.MARKETPLACESTORE,
	false,
	"marketplaceSeller",
	null,
	false,
	true,
	CollectionType.COLLECTION
	);
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(NAME, AttributeMode.INITIAL);
		tmp.put(BASESTORE, AttributeMode.INITIAL);
		tmp.put(MARKETPLACE, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.baseStore</code> attribute.
	 * @return the baseStore - Base Store
	 */
	public BaseStore getBaseStore(final SessionContext ctx)
	{
		return (BaseStore)getProperty( ctx, BASESTORE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.baseStore</code> attribute.
	 * @return the baseStore - Base Store
	 */
	public BaseStore getBaseStore()
	{
		return getBaseStore( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.baseStore</code> attribute. 
	 * @param value the baseStore - Base Store
	 */
	public void setBaseStore(final SessionContext ctx, final BaseStore value)
	{
		setProperty(ctx, BASESTORE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.baseStore</code> attribute. 
	 * @param value the baseStore - Base Store
	 */
	public void setBaseStore(final BaseStore value)
	{
		setBaseStore( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.marketplace</code> attribute.
	 * @return the marketplace - Marketplace
	 */
	public Marketplace getMarketplace(final SessionContext ctx)
	{
		return (Marketplace)getProperty( ctx, MARKETPLACE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.marketplace</code> attribute.
	 * @return the marketplace - Marketplace
	 */
	public Marketplace getMarketplace()
	{
		return getMarketplace( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.marketplace</code> attribute. 
	 * @param value the marketplace - Marketplace
	 */
	public void setMarketplace(final SessionContext ctx, final Marketplace value)
	{
		setProperty(ctx, MARKETPLACE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.marketplace</code> attribute. 
	 * @param value the marketplace - Marketplace
	 */
	public void setMarketplace(final Marketplace value)
	{
		setMarketplace( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.marketplaceStores</code> attribute.
	 * @return the marketplaceStores
	 */
	public Collection<MarketplaceStore> getMarketplaceStores(final SessionContext ctx)
	{
		return MARKETPLACESTORESHANDLER.getValues( ctx, this );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.marketplaceStores</code> attribute.
	 * @return the marketplaceStores
	 */
	public Collection<MarketplaceStore> getMarketplaceStores()
	{
		return getMarketplaceStores( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.marketplaceStores</code> attribute. 
	 * @param value the marketplaceStores
	 */
	public void setMarketplaceStores(final SessionContext ctx, final Collection<MarketplaceStore> value)
	{
		MARKETPLACESTORESHANDLER.setValues( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.marketplaceStores</code> attribute. 
	 * @param value the marketplaceStores
	 */
	public void setMarketplaceStores(final Collection<MarketplaceStore> value)
	{
		setMarketplaceStores( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to marketplaceStores. 
	 * @param value the item to add to marketplaceStores
	 */
	public void addToMarketplaceStores(final SessionContext ctx, final MarketplaceStore value)
	{
		MARKETPLACESTORESHANDLER.addValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to marketplaceStores. 
	 * @param value the item to add to marketplaceStores
	 */
	public void addToMarketplaceStores(final MarketplaceStore value)
	{
		addToMarketplaceStores( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from marketplaceStores. 
	 * @param value the item to remove from marketplaceStores
	 */
	public void removeFromMarketplaceStores(final SessionContext ctx, final MarketplaceStore value)
	{
		MARKETPLACESTORESHANDLER.removeValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from marketplaceStores. 
	 * @param value the item to remove from marketplaceStores
	 */
	public void removeFromMarketplaceStores(final MarketplaceStore value)
	{
		removeFromMarketplaceStores( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.name</code> attribute.
	 * @return the name - Seller Name
	 */
	public String getName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>MarketplaceSeller.name</code> attribute.
	 * @return the name - Seller Name
	 */
	public String getName()
	{
		return getName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.name</code> attribute. 
	 * @param value the name - Seller Name
	 */
	public void setName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>MarketplaceSeller.name</code> attribute. 
	 * @param value the name - Seller Name
	 */
	public void setName(final String value)
	{
		setName( getSession().getSessionContext(), value );
	}
	
}
