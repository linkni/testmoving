/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 2016-2-9 20:13:46                           ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *  
 */
package com.hybris.backoffice.jalo;

import com.hybris.backoffice.jalo.TmallOrderStatus;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.type.CollectionType;
import de.hybris.platform.marketplaceintegration.constants.MarketplaceintegrationConstants;
import de.hybris.platform.util.OneToManyHandler;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Generated class for type {@link com.hybris.backoffice.jalo.Marketplace Marketplace}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedMarketplace extends GenericItem
{
	/** Qualifier of the <code>Marketplace.code</code> attribute **/
	public static final String CODE = "code";
	/** Qualifier of the <code>Marketplace.name</code> attribute **/
	public static final String NAME = "name";
	/** Qualifier of the <code>Marketplace.url</code> attribute **/
	public static final String URL = "url";
	/** Qualifier of the <code>Marketplace.adapterUrl</code> attribute **/
	public static final String ADAPTERURL = "adapterUrl";
	/** Qualifier of the <code>Marketplace.timezone</code> attribute **/
	public static final String TIMEZONE = "timezone";
	/** Qualifier of the <code>Marketplace.tmallOrderStatus</code> attribute **/
	public static final String TMALLORDERSTATUS = "tmallOrderStatus";
	/**
	* {@link OneToManyHandler} for handling 1:n TMALLORDERSTATUS's relation attributes from 'many' side.
	**/
	protected static final OneToManyHandler<TmallOrderStatus> TMALLORDERSTATUSHANDLER = new OneToManyHandler<TmallOrderStatus>(
	MarketplaceintegrationConstants.TC.TMALLORDERSTATUS,
	false,
	"marketplace",
	"marketplacePOS",
	true,
	true,
	CollectionType.LIST
	);
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(CODE, AttributeMode.INITIAL);
		tmp.put(NAME, AttributeMode.INITIAL);
		tmp.put(URL, AttributeMode.INITIAL);
		tmp.put(ADAPTERURL, AttributeMode.INITIAL);
		tmp.put(TIMEZONE, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.adapterUrl</code> attribute.
	 * @return the adapterUrl - Adapter URL
	 */
	public String getAdapterUrl(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ADAPTERURL);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.adapterUrl</code> attribute.
	 * @return the adapterUrl - Adapter URL
	 */
	public String getAdapterUrl()
	{
		return getAdapterUrl( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.adapterUrl</code> attribute. 
	 * @param value the adapterUrl - Adapter URL
	 */
	public void setAdapterUrl(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ADAPTERURL,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.adapterUrl</code> attribute. 
	 * @param value the adapterUrl - Adapter URL
	 */
	public void setAdapterUrl(final String value)
	{
		setAdapterUrl( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.code</code> attribute.
	 * @return the code - Code
	 */
	public String getCode(final SessionContext ctx)
	{
		return (String)getProperty( ctx, CODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.code</code> attribute.
	 * @return the code - Code
	 */
	public String getCode()
	{
		return getCode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.code</code> attribute. 
	 * @param value the code - Code
	 */
	public void setCode(final SessionContext ctx, final String value)
	{
		setProperty(ctx, CODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.code</code> attribute. 
	 * @param value the code - Code
	 */
	public void setCode(final String value)
	{
		setCode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.name</code> attribute.
	 * @return the name - Name
	 */
	public String getName(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMarketplace.getName requires a session language", 0 );
		}
		return (String)getLocalizedProperty( ctx, NAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.name</code> attribute.
	 * @return the name - Name
	 */
	public String getName()
	{
		return getName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.name</code> attribute. 
	 * @return the localized name - Name
	 */
	public Map<Language,String> getAllName(final SessionContext ctx)
	{
		return (Map<Language,String>)getAllLocalizedProperties(ctx,NAME,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.name</code> attribute. 
	 * @return the localized name - Name
	 */
	public Map<Language,String> getAllName()
	{
		return getAllName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.name</code> attribute. 
	 * @param value the name - Name
	 */
	public void setName(final SessionContext ctx, final String value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMarketplace.setName requires a session language", 0 );
		}
		setLocalizedProperty(ctx, NAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.name</code> attribute. 
	 * @param value the name - Name
	 */
	public void setName(final String value)
	{
		setName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.name</code> attribute. 
	 * @param value the name - Name
	 */
	public void setAllName(final SessionContext ctx, final Map<Language,String> value)
	{
		setAllLocalizedProperties(ctx,NAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.name</code> attribute. 
	 * @param value the name - Name
	 */
	public void setAllName(final Map<Language,String> value)
	{
		setAllName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.timezone</code> attribute.
	 * @return the timezone - Interface Timezone
	 */
	public String getTimezone(final SessionContext ctx)
	{
		return (String)getProperty( ctx, TIMEZONE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.timezone</code> attribute.
	 * @return the timezone - Interface Timezone
	 */
	public String getTimezone()
	{
		return getTimezone( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.timezone</code> attribute. 
	 * @param value the timezone - Interface Timezone
	 */
	public void setTimezone(final SessionContext ctx, final String value)
	{
		setProperty(ctx, TIMEZONE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.timezone</code> attribute. 
	 * @param value the timezone - Interface Timezone
	 */
	public void setTimezone(final String value)
	{
		setTimezone( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.tmallOrderStatus</code> attribute.
	 * @return the tmallOrderStatus
	 */
	public List<TmallOrderStatus> getTmallOrderStatus(final SessionContext ctx)
	{
		return (List<TmallOrderStatus>)TMALLORDERSTATUSHANDLER.getValues( ctx, this );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.tmallOrderStatus</code> attribute.
	 * @return the tmallOrderStatus
	 */
	public List<TmallOrderStatus> getTmallOrderStatus()
	{
		return getTmallOrderStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.tmallOrderStatus</code> attribute. 
	 * @param value the tmallOrderStatus
	 */
	public void setTmallOrderStatus(final SessionContext ctx, final List<TmallOrderStatus> value)
	{
		TMALLORDERSTATUSHANDLER.setValues( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.tmallOrderStatus</code> attribute. 
	 * @param value the tmallOrderStatus
	 */
	public void setTmallOrderStatus(final List<TmallOrderStatus> value)
	{
		setTmallOrderStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to tmallOrderStatus. 
	 * @param value the item to add to tmallOrderStatus
	 */
	public void addToTmallOrderStatus(final SessionContext ctx, final TmallOrderStatus value)
	{
		TMALLORDERSTATUSHANDLER.addValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to tmallOrderStatus. 
	 * @param value the item to add to tmallOrderStatus
	 */
	public void addToTmallOrderStatus(final TmallOrderStatus value)
	{
		addToTmallOrderStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from tmallOrderStatus. 
	 * @param value the item to remove from tmallOrderStatus
	 */
	public void removeFromTmallOrderStatus(final SessionContext ctx, final TmallOrderStatus value)
	{
		TMALLORDERSTATUSHANDLER.removeValue( ctx, this, value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from tmallOrderStatus. 
	 * @param value the item to remove from tmallOrderStatus
	 */
	public void removeFromTmallOrderStatus(final TmallOrderStatus value)
	{
		removeFromTmallOrderStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.url</code> attribute.
	 * @return the url - URL
	 */
	public String getUrl(final SessionContext ctx)
	{
		return (String)getProperty( ctx, URL);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Marketplace.url</code> attribute.
	 * @return the url - URL
	 */
	public String getUrl()
	{
		return getUrl( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.url</code> attribute. 
	 * @param value the url - URL
	 */
	public void setUrl(final SessionContext ctx, final String value)
	{
		setProperty(ctx, URL,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Marketplace.url</code> attribute. 
	 * @param value the url - URL
	 */
	public void setUrl(final String value)
	{
		setUrl( getSession().getSessionContext(), value );
	}
	
}
